---
Title: Buen Vivir: The Social Philosophy Inspiring Movements in South America
Author: Oliver Balch
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# Buen Vivir: The Social Philosophy Inspiring Movements in South America

![rw-book-cover](https://i.guim.co.uk/img/static/sys-images/Guardian/Pix/pictures/2013/2/1/1359732637870/Huaorani-Indian-children--008.jpg?width=1200&height=630&quality=85&auto=format&fit=crop&overlay-align=bottom%2Cleft&overlay-width=100p&overlay-base64=L2ltZy9zdGF0aWMvb3ZlcmxheXMvdGctZGVmYXVsdC5wbmc&enable=upscale&s=3948f85d5cd1a9fc64c51c742c5ee0a9)

## Metadata
- Author: [[Oliver Balch]]
- Full Title: Buen Vivir: The Social Philosophy Inspiring Movements in South America
- Source: reader
- Category: #articles
- URL: https://www.theguardian.com/sustainable-business/blog/buen-vivir-philosophy-south-america-eduardo-gudynas

## Highlights
- Similar thinking is inspiring other social movements across South America, says ([View Highlight](https://read.readwise.io/read/01gma40a2g6vj4b0x4tvrpks0a))
