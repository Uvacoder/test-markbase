%% Begin Waypoint %%
- [[🟡Semafor Tech Reckless]]
- [[A Civic Technologist's Practice Guide]]
- [[Buen Vivir The Social Philosophy Inspiring Movements in South America]]
- [[Builder Brain]]
- [[Kill It With Fire]]

%% End Waypoint %%
