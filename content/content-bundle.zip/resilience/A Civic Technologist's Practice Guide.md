---
Title: A Civic Technologist's Practice Guide
Author: Cyd Harrell
Tags: to_process, readwise, books, kindle
date: 2022-12-19
---
# A Civic Technologist's Practice Guide

![rw-book-cover](https://m.media-amazon.com/images/I/818ALomchrL._SY160.jpg)

## Metadata
- Author: [[Cyd Harrell]]
- Full Title: A Civic Technologist's Practice Guide
- Source: kindle
- Category: #books

## Highlights
- showing what’s possible and doing what’s necessary ([Location 88](https://readwise.io/to_kindle?action=open&asin=B08GZWMGMQ&location=88))
- But our job as civic technologists isn’t to be the hero of the stories we stumble into halfway through; it’s to understand and support the people who have already been in place doing ([Location 389](https://readwise.io/to_kindle?action=open&asin=B08GZWMGMQ&location=389))
- It would be ridiculous only to work with partners who are already practicing exactly how you’d hope they would, but it’s a recipe for misery to sign on with those who are fully committed to practices you think are antithetical to the change you aspire to drive. ([Location 665](https://readwise.io/to_kindle?action=open&asin=B08GZWMGMQ&location=665))
- You can easily contribute your labor to this cause if you’re coming from the design or information architecture disciplines. ([Location 793](https://readwise.io/to_kindle?action=open&asin=B08GZWMGMQ&location=793))
- there are legitimate worries about how to duplicate the security of isolated data centers for certain purposes. ([Location 820](https://readwise.io/to_kindle?action=open&asin=B08GZWMGMQ&location=820))
- It’s true that nothing new can be made without some risk, but technologists are often too cavalier about failure even in their ([Location 890](https://readwise.io/to_kindle?action=open&asin=B08GZWMGMQ&location=890))
