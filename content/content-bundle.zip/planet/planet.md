%% Begin Waypoint %%
- [[Analysis Africa’s Unreported Extreme Weather in 2022 and Climate Change]]
- [[Mine Your Business]]

%% End Waypoint %%
