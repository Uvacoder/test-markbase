---
Title: Mine Your Business
Author: International Intrigue
Tags: readwise, articles, reader
date: 2022-12-19
---
# 🌍 Mine Your Business

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[International Intrigue]]
- Full Title: 🌍 Mine Your Business
- Source: reader
- Category: #articles #planet #minerals

## Highlights
- According to the [International Energy Agency](https://link.mail.beehiiv.com/ss/c/gMDlt5V9FS6Ks-MMyAzMnb70lJ-wZXMb2B7myvt9QLzl2EW9CPmY5BuYogWxo9-z5YoOxjc0KRWCq8Bu93GQSe103ijdKxUUK1mghXa4m3T0NEouTvM-8I3g6FsV6rz1UYTA5mibCFvVegIKJ2vPow/3rt/wQ8SdK60Q7-4egR9_tv8Ow/h9/U7jglul7Yvt_asC4FwU704DWVd4OQRLKoaOXlVtLNr4) , the average electric car requires more than 200 kilograms of critical minerals, six times that of a conventional combustion vehicle. ([View Highlight](https://read.readwise.io/read/01gkynd213tx54fvrtx4983wbx))
- Minerals like lithium, cobalt, and copper are geographically concentrated in a few countries, and mining for them can be politically divisive and environmentally destructive. ([View Highlight](https://read.readwise.io/read/01gkyndgdapz37byvnr7krvgyz))
- Lithium is a key component in the rechargeable lithium-ion batteries that power electric vehicles, smartphones, and solar panels. **And Latin America has a lot of it.** ([View Highlight](https://read.readwise.io/read/01gkynfdmhawtff240xn9xf0h1))
- Chilean regulators have [levied hefty fines](https://link.mail.beehiiv.com/ss/c/gMDlt5V9FS6Ks-MMyAzMndD0KZg5jSsn89nIo3RWHMopnifYLA_lvC6msJ7K-dTBme6Z2SNUUjieNfriANfVFwM21HNaRHX_nPVCVRXYriohd3R-VrGLUYfANhIylEN3trmRQ2JIEzzGx66KqA1cfw/3rt/wQ8SdK60Q7-4egR9_tv8Ow/h10/a826W6EDk6jdwPWhFPN1mmN21-9Ap6tb4qiJwaFSKgw) against mining companies in the lithium-rich Atacama Desert for over-extracting groundwater. ([View Highlight](https://read.readwise.io/read/01gkynfyrys8y5z992g5fw55cy))
- The Democratic Republic of the Congo produces 70% of the world’s cobalt, an extremely rare mineral which keeps lithium-ion batteries from catching fire. ([View Highlight](https://read.readwise.io/read/01gkyng7f25g7yjf3b44ax11gf))
- **But DR Congo is a war-torn country with poor labour laws** , and a large percentage of cobalt extraction is done by unregulated artisanal miners called *creuseurs* .
  • As reported by the [New Yorker](https://link.mail.beehiiv.com/ss/c/gMDlt5V9FS6Ks-MMyAzMnfMXexZy7dFrtqnHwFxBjMavIj1JvppeKPs4_fT02svU--9occI6W2kg6P66VAwgcolE85zFYCDvdEy13l_oJM_rY0QiPZ9aKq3xz-lRirFX/3rt/wQ8SdK60Q7-4egR9_tv8Ow/h12/VK0Ok-K-_UDfrXgpI7XwZRah3qvzmv4V4GQ05eZWtMI) , *creuseurs* are often killed by mine cave-ins and experience violence and sexual abuse by local militants. ([View Highlight](https://read.readwise.io/read/01gkyngvapes2620pvmg5s413g))
- **And about 60% of rare earth mining and 85% of its processing** **occurs in China,** [which gives it enormous leverage](https://link.mail.beehiiv.com/ss/c/bzagCTIVwYiyLO7g1WljWj4XduQzCJp96i4PgZyo-Zlf3oEgeSauGsljpdLaIZoqMi9lXRNOInNE8TTyWonHyDyv-1SNV-jykEMCqCjqmHxq5DRyt6BF9gZuJrr9CDM6qWizwS0OC5olJgTTHN4D-z-xb1VN0Al1fqPBw5zDBd9_FXd1yO0Q--zDhVkspKWvUmu5Xg957AwA1pMB6LPnAlhAXwdT20IXg5Kc3XvT7D4xB09npd1wMzWSG6E1_NUz/3rt/wQ8SdK60Q7-4egR9_tv8Ow/h14/_-pTp0DoBzuBEWFKFKwr6JGLDpupYHqeTo7oiybu6Tg) over the US and Western allies: ([View Highlight](https://read.readwise.io/read/01gkynkyt25cks7trssgj5et72))
- Amnesty International’s Canadian office was [targeted by Beijing-backed hackers](https://link.mail.beehiiv.com/ss/c/gMDlt5V9FS6Ks-MMyAzMnSL7eFNCmFq4HFfqf0we8uQsF13ZaKEOKOIDLS7sW9ov5YIvV1-E2QJOfoGaDcualZ74s2k3Klk3AMRL5obf70fkRMLQcdikyYa53dLwZwrmHg6n_xj5-dkdBMUULPCGEg/3rt/wQ8SdK60Q7-4egR9_tv8Ow/h22/AlnoCu_udyJCMT7cAzGE-NHtRrDeSy5cK1Bi_MuTRkA) , according to Canadian investigators. ([View Highlight](https://read.readwise.io/read/01gkynn68dh8vqt5nv5b1j94s2))
