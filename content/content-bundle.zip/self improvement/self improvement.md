%% Begin Waypoint %%
- [[Following Your Passion Is Great in Concept, but It Is...]]

%% End Waypoint %%
