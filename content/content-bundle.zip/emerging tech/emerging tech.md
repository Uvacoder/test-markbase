%% Begin Waypoint %%
- [[A Libertarian ‘Startup City’ in Honduras Faces Its Biggest Hurdle The Locals]]

%% End Waypoint %%
