---
Title: A Libertarian ‘Startup City’ in Honduras Faces Its Biggest Hurdle: The Locals
Author: restofworld.org
Tags: to_process, readwise, articles, instapaper
date: 2022-12-19
---
# A Libertarian ‘Startup City’ in Honduras Faces Its Biggest Hurdle: The Locals

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[restofworld.org]]
- Full Title: A Libertarian ‘Startup City’ in Honduras Faces Its Biggest Hurdle: The Locals
- Source: instapaper
- Category: #articles
- URL: https://restofworld.org/2021/honduran-islanders-push-back-libertarian-startup/

## Highlights
- Government services will be centralized and automated through ePróspera, an online portal modeled on the much-praised e-Estonia system developed by the Baltic nation. From the comfort of their homes, Prósperans will be able to pay taxes, incorporate a company, transact business, and even buy real estate. They’ll be able to vote, too, but their franchise is limited. Residents elect only five of the council’s nine members. Landowners vote for two of the five, with voting power pegged to acreage. Buy more land, buy more votes. Próspera’s founders choose the four remaining council members, and a six-member supermajority is needed to alter policy. ([View Highlight](https://instapaper.com/read/1464049433/18214140))
