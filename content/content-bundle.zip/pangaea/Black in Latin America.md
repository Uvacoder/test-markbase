---
Title: Black in Latin America
Author: Henry Louis Gates Jr.
Tags: to_process, readwise, books, kindle
date: 2022-12-19
---
# Black in Latin America

![rw-book-cover](https://m.media-amazon.com/images/I/71dJpzdyJPL._SY160.jpg)

## Metadata
- Author: [[Henry Louis Gates Jr.]]
- Full Title: Black in Latin America
- Source: kindle
- Category: #books

## Highlights
- North Americans,” he concluded quite pungently, “tend to be as blind about the centrality of class in our society and vigilant about the centrality of race as Latin Americans are vigilant about the reality of class and blind about the reality of race.” ([Location 128](https://readwise.io/to_kindle?action=open&asin=B005C9GNTQ&location=128))
- In his autobiography, Along This Way, Johnson relates the curious and amusing story that, just as he and a companion traveling on a train are about to be booted from a “first-class car,” or a white car, and removed to the Jim Crow car, they talk to each other in Spanish. This is what happens when they do: As soon as the conductor heard us speaking in a foreign language, his attitude changed; he punched our tickets and gave them back, and treated us just as he did the other passengers in the car. … ([Location 221](https://readwise.io/to_kindle?action=open&asin=B005C9GNTQ&location=221))
- Fifteen years later, an incident similar to the experience with this conductor drove home to me the conclusion that in such situations any kind of a Negro will do; provided he is not one who is an American citizen. ([Location 225](https://readwise.io/to_kindle?action=open&asin=B005C9GNTQ&location=225))
- In the United States, in contrast, no amount of wealth or behavior would ever make a black-skinned person “white,” and that is a fundamental difference between the two societies. Class was fluid in Brazil, in a way that it was not for black people in the United States. ([Location 660](https://readwise.io/to_kindle?action=open&asin=B005C9GNTQ&location=660))
- New scholarship by the historian David Wheat has shown that the Cartagena leg of the slave trade (leading to Colombia and Peru) had more African nations involved. While the largest single group still originated in Angola, their total number was about half; Senegambia and Sierra Leone come second, ([Location 1671](https://readwise.io/to_kindle?action=open&asin=B005C9GNTQ&location=1671))
- We shook hands on a bright street corner in Malambo, now called the District of Rímac. It was a bustling, vibrant black neighborhood—the Harlem of Lima, I thought. ([Location 1713](https://readwise.io/to_kindle?action=open&asin=B005C9GNTQ&location=1713))
- This small nation—a country that takes up about one-third of the island of Hispaniola, about the size of Maryland—absorbed perhaps 350,000 more slaves than the total number that came to the United States. ([Location 2680](https://readwise.io/to_kindle?action=open&asin=B005C9GNTQ&location=2680))
- Over 220,000 Haitians lost their lives, and today, a million and a half are still homeless. ([Location 2689](https://readwise.io/to_kindle?action=open&asin=B005C9GNTQ&location=2689))
- During the nineteen-year occupation, Delatour explained, the United States appropriated Haitian land. It exercised veto power over the government’s decisions. It even rewrote the country’s constitution, making it legal for whites from other countries to own land in Haiti. ([Location 3067](https://readwise.io/to_kindle?action=open&asin=B005C9GNTQ&location=3067))
- The United States sent its most racist troops to Haiti, I learned—Marines from the South who thought of blacks as less than human. This reopened many of Haiti’s colonial wounds. Politically, socially, economically, the country was set back again, by decades. ([Location 3071](https://readwise.io/to_kindle?action=open&asin=B005C9GNTQ&location=3071))
- “The official policies of the North American government were incredibly racist. And they tried, during the ([Location 3276](https://readwise.io/to_kindle?action=open&asin=B005C9GNTQ&location=3276))
- Because the black human being is a free human being. We show what we feel.” ([Location 3353](https://readwise.io/to_kindle?action=open&asin=B005C9GNTQ&location=3353))
- The idea that national pride can supersede racial identity had spread all across Latin America. ([Location 3506](https://readwise.io/to_kindle?action=open&asin=B005C9GNTQ&location=3506))
