%% Begin Waypoint %%
- [[A Global Community‐sourced Assessment of the State of Conservation Technology]]
- [[career in conservation tech]]
- [[remote sensing]]

%% End Waypoint %%


