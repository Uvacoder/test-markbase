---
Title: 
Author: WildLabs
Tags: #conservationtech
date: 2022-10-18
---

## What is it
Remote sensing is a technology that measures electromagnetic radiation to extract information on this earth's land surface, sea, and atmosphere

Advantages
- unobtrusive
- systematic
- meaningful information

Limitations
- oversold
- human errors in interpretation and processing
- expensive







